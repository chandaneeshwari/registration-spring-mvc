package com.virtusa.registration;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {


//
// @InitBinder
// public void initBinder(WebDataBinder binder) {
// binder.setDisallowedFields(new String[] {"mobileNumber"});
// }

// @RequestMapping("/register")
// public ModelAndView Registration() {
//
// ModelAndView mv = new ModelAndView("RegistrationForm");
//
// return mv;
// }

/* every time we no need to add this object ,we can assign the value only once and can use this wherever you want with the help of Model class
 whenever a controller class has a modelattribute annotation likethis then springmvc framework will always make a call to that method first
 we use this for two reasons
 1.it will automatically bind all the request parameters submitted by user(no need to set the object)
 2. in coressponding jsp we can view details by simply refering the key
*
*/
@ModelAttribute
public void addingCommonObjects(Model model) {

model.addAttribute("message", "welcome user");

}
@RequestMapping("/")
public String check() {
	
	String exceptionOccured="NULL_POINTER";
//	String exceptionOccured="ARITHEMATIC";
	if(exceptionOccured.equalsIgnoreCase("NULL_POINTER")) {
		throw new NullPointerException("Null Pointer Exception");
	}
	else if (exceptionOccured.equalsIgnoreCase("ARITHEMATIC")) {
		throw new ArithmeticException("ARITHEMATIC Exception");
	}
return "index";
}
@RequestMapping("/viewregister")
public ModelAndView ViewRegistration(@Valid @ModelAttribute("student1") Student student1,BindingResult result) {
if(result.hasErrors()) {
ModelAndView mv = new ModelAndView("index");
return mv;
}
 
ModelAndView mv = new ModelAndView("ViewRegistrationForm");
mv.addObject("firstName", student1.getFirstName());

mv.addObject("lastName", student1.getLastName());
mv.addObject("mobilnumber", student1.getMobileNumber());
//mv.addObject("dob", student1.getDateOfBirth());
//mv.addObject("skills", student1.getStudentSkills());

return mv;
}
@ExceptionHandler(value= NullPointerException.class)
public String handleNullPointerException(Exception e) {
	//logging Null Pointer Exception
	System.out.println("Null Pointer Exception Occured:"+e);
	return "NullPointerException";
}

}