package com.virtusa.registration;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Student {
@NotNull(message="required")
@Size(min=2,max=5)//,message="please enter a value between 2 and 5")
//giving custom error in properties file


@Pattern(regexp="[^0-9]*")
private String FirstName;
	
@NotNull
@Size(min=2,max=5,message="please enter a value between 2 and 5")
@Pattern(regexp="[^0-9]*")
private String LastName;

@NotNull
@Max(666)
@Min(333)
private Long mobileNumber;
//private Date DateOfBirth;
//private ArrayList<String> studentSkills;
public Long getMobileNumber() {
return mobileNumber;
}
public void setMobileNumber(Long mobileNumber) {
this.mobileNumber = mobileNumber;
}
//public Date getDateOfBirth() {
// return DateOfBirth;
//}
//public void setDateOfBirth(Date dateOfBirth) {
// DateOfBirth = dateOfBirth;
//}
//public ArrayList<String> getStudentSkills() {
// return studentSkills;
//}
//public void setStudentSkills(ArrayList<String> studentSkills) {
// this.studentSkills = studentSkills;
//}
public String getFirstName() {
return FirstName;
}
public void setFirstName(String firstName) {
FirstName = firstName;
}
public String getLastName() {
return LastName;
}
public void setLastName(String lastName) {
LastName = lastName;
}
@Override
public String toString() {
return "Student [FirstName=" + FirstName + ", LastName=" + LastName + ", mobileNumber=" + mobileNumber
+   "]";
}

}
