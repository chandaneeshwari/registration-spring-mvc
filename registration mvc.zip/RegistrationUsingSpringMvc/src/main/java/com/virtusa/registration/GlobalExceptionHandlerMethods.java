package com.virtusa.registration;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandlerMethods {
 
	
	@ExceptionHandler(value= Exception.class)
	public String handleNullPointerException(Exception e) {
		//logging Null Pointer Exception
		System.out.println("unknown Exception Occured:"+e);
		return "GlobalException";
	}
}
